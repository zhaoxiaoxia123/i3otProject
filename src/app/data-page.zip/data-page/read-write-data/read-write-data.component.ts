import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-read-write-data',
  templateUrl: './read-write-data.component.html',
  styleUrls: ['./read-write-data.component.css']
})
export class ReadWriteDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
