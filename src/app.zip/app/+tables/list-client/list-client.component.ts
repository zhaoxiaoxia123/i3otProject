import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-client',
  templateUrl: './list-client.component.html',
})
export class ListClientComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
