import { NgModule } from '@angular/core';

import {routing} from './management-routing.module';


@NgModule({
    declarations: [
    ],
    imports: [
        routing,
    ],
    providers: [
    ],
})
export class ManagementModule { }
