export {LoginInfoComponent} from './login-info.component';
