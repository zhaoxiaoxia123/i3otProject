export {FileInputComponent} from './file-input.component';
