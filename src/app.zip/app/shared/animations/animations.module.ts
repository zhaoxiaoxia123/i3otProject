/**
 * Created by griga on 12/26/16.
 */

import {NgModule} from "@angular/core";

import {CommonModule} from "@angular/common";

@NgModule({
  imports: [CommonModule],
  declarations: [
  ],
  exports: []

})
export class SmartadminFormsLiteModule{}
