import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-stats',
  templateUrl: './stats.component.html'
})
export class StatsComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
