export { FooterComponent } from './footer.component';
